#include "../include/comandos.h"
#include <iostream>
using namespace std;

void Comando::processar(const string& comando) {
    if (comando == "sair") {
        cout << "Simulacao encerrada. Obrigado!" << endl;
        exit(0);  // Termina o programa
    } else if (comando == "avanca") {
        cout << "Avancando para o proximo instante..." << endl;
        // Placeholder: por enquanto, só reimprime a grelha
        jardim.imprimir();
    } else {
        cout << "Comando invalido! Tente 'sair' ou 'avanca'." << endl;
    }
}