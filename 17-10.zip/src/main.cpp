#include <iostream>
#include <limits>
#include "../include/jardim.h"
#include "../include/Settings.h"
#include "../include/comandos.h"
using namespace std;

int main() {
    int linhas, colunas;

    do {
        cout << "Digite o numero de linhas (1 a 26): ";
        cin >> linhas;

        cout << "Digite o numero de colunas (1 a 26): ";
        cin >> colunas;

        if (linhas < 1 || linhas > 26 || colunas < 1 || colunas > 26) {
            cout << "Dimensoes invalidas! Insira valores entre 1 e 26." << endl;
        }
        if (cin.fail()) {
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
        }
    } while (linhas < 1 || linhas > 26 || colunas < 1 || colunas > 26 || cin.fail());

    Jardim jardim(linhas, colunas);

    cout << "\nGrelha inicial:" << endl;
    jardim.imprimir();
    cin.ignore(1000, '\n');  // descarta até 1000 caracteres ou até encontrar '\n'
    // Criar objeto Comando
    Comando comando(jardim);

    // Loop com processamento de comandos
    string entrada;
    while (true) {
        cout << "\nDigite um comando (ex: 'sair' ou 'avanca'): ";
        getline(cin, entrada);
        comando.processar(entrada);
    }
    return 0;
}