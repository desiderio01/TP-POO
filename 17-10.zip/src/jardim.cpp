#include "../include/jardim.h"
#include <iostream>
#include <cstdlib>  // Para rand() e srand()
#include <ctime>    // Para inicializar rand() com tempo
#include "../include/Settings.h"  // Inclui as constantes
using namespace std;

Jardim::Jardim(int lin, int col) {
    linhas = lin;
    colunas = col;
    // Aloca a grelha dinamicamente
    grelha = new Celula*[linhas];  // Cria array de ponteiros
    for (int i = 0; i < linhas; i++) {
        grelha[i] = new Celula[colunas];  // Cria cada linha
    }
    // Inicializa água e nutrientes aleatoriamente com base em Settings
    srand(time(0));  // Inicializa o gerador de números aleatórios
    for (int i = 0; i < linhas; i++) {
        for (int j = 0; j < colunas; j++) {
            grelha[i][j].setAgua(rand() % (Settings::Jardim::agua_max - Settings::Jardim::agua_min + 1) + Settings::Jardim::agua_min);
            grelha[i][j].setNutrientes(rand() % (Settings::Jardim::nutrientes_max - Settings::Jardim::nutrientes_min + 1) + Settings::Jardim::nutrientes_min);
        }
    }
}

Jardim::~Jardim() {
    // Libera a memória alocada
    for (int i = 0; i < linhas; i++) {
        delete[] grelha[i];  // Libera cada linha
    }
    delete[] grelha;  // Libera o array de ponteiros
}

void Jardim::imprimir() {
    // Imprime a régua superior (colunas)
    cout << "  ";
    for (int j = 0; j < colunas; j++) {
        cout << static_cast<char>('A' + j) << " ";
    }
    cout << endl;

    // Imprime cada linha com a régua lateral
    for (int i = 0; i < linhas; i++) {
        cout << static_cast<char>('A' + i) << " ";
        for (int j = 0; j < colunas; j++) {
            cout << "." << " ";
        }
            cout << endl;
    }
}