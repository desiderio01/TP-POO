//
// Created by david on 17/10/2025.
//

#ifndef CELULA_H
#define CELULA_H

class Celula {
private:
    int agua;
    int nutrientes;
public:
    void setAgua(int a) { agua = a; }
    void setNutrientes(int n) { nutrientes = n; }
};

#endif //CELULA_H
