//
// Created by david on 17/10/2025.
//

#ifndef JARDINEIRO_H
#define JARDINEIRO_H



class jardineiro {

};



#endif //JARDINEIRO_H
