#ifndef JARDIM_H
#define JARDIM_H

#include "celula.h"

class Jardim {
private:
    Celula** grelha;
    int linhas;
    int colunas;

public:
    //inicializa a grelha com o tamanho especificado
    Jardim(int lin, int col);

    //libera a memória alocada
    ~Jardim();

    //imprimir a grelha com a régua
    void imprimir();
};

#endif //JARDIM_H