#ifndef COMANDOS_H
#define COMANDOS_H

#include <string>
#include "jardim.h"

class Comando {
private:
    Jardim& jardim;  // Referência ao objeto Jardim para acessar a grelha

public:
    // Construtor que recebe o Jardim
    Comando(Jardim& j) : jardim(j) {}

    // Método para processar o comando
    void processar(const std::string& comando);
};

#endif //COMANDOS_H