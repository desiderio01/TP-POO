#ifndef COMANDOS_H
#define COMANDOS_H

#include <string>
#include <vector>
using namespace std;

// Divide uma string por espaços (sem sstream)
vector<string> dividirTokens(const string &linha);

// Converte posição do tipo "ab" → (linha, coluna)
bool converterPosicao(const string &txt, int &linha, int &coluna);

// Verifica se string é inteiro
bool eInteiro(const string &txt);

// Processa comando e retorna false se for para terminar
bool processarComando(const string &linha);

#endif
