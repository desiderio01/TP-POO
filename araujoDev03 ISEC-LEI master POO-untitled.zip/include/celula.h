//
// Created by David Ribeiro Tavares e Silva de Araújo on 16/10/2025.
//

#ifndef CEL_H
#define CEL_H



class celula {

};



#endif //CEL_H
