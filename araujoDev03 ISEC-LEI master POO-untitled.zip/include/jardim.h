//
// Created by David Ribeiro Tavares e Silva de Araújo on 16/10/2025.
//

#ifndef JARDIM_H
#define JARDIM_H



class jardim {

};



#endif //JARDIM_H
