//
// Created by David Ribeiro Tavares e Silva de Araújo on 16/10/2025.
//

#ifndef JARDINEIRO_H
#define JARDINEIRO_H



class jardineiro {

};



#endif //JARDINEIRO_H
