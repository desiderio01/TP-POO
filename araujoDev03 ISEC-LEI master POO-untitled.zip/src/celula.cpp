//
// Created by David Ribeiro Tavares e Silva de Araújo on 16/10/2025.
//

#include "../include/celula.h"
