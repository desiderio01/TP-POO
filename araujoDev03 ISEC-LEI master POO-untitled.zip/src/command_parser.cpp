//
// Created by David Ribeiro Tavares e Silva de Araújo on 16/10/2025.
//

    #include "../include/command_parser.h"

#include <iostream>
#include <cctype>

using namespace std;

// ---------- Funções auxiliares ----------
vector<string> dividirTokens(const string &linha) {
    vector<string> tokens;
    string atual;

    for (char c : linha) {
        // isspace retorna 0 ou 1 se tiver espaços na string
        if (isspace(c)) {
            if (!atual.empty()) {
                tokens.push_back(atual);
                atual.clear();
            }
        } else {
            atual += c;
        }
    }
    if (!atual.empty()) tokens.push_back(atual);
    return tokens;
}

bool eInteiro(const string &txt) {
    if (txt.empty()) return false;
    for (char c : txt) {
        if (!isdigit(c)) return false;
    }
    return true;
}

bool converterPosicao(const string &txt, int &linha, int &coluna) {
    // exemplo: "ab" → linha=0, coluna=1
    if (txt.size() != 2) return false;
    char l = tolower(txt[0]);
    char c = tolower(txt[1]);
    if (l < 'a' || c < 'a' || l > 'z' || c > 'z') return false;
    linha = l - 'a';
    coluna = c - 'a';
    return true;
}

// ---------- Processamento de comandos ----------
bool processarComando(const string &linha) {
    auto tokens = dividirTokens(linha);
    if (tokens.empty()) return true;

    string cmd = tokens[0];

    // Lista de comandos reconhecidos
    const vector<string> validos = {
        "jardim", "avanca", "planta", "colhe", "entra", "sai", "pega", "larga",
        "compra", "lplanta", "lareira", "lsolo", "lferr", "executa", "grava",
        "recupera", "apaga", "fim", "e", "d", "c", "b", "movimentos"
    };

    // Verificar se é comando válido
    bool conhecido = false;
    for (auto &v : validos)
        if (cmd == v) { conhecido = true; break; }

    if (!conhecido) {
        cout << "comando inválido\n";
        return true;
    }

    // ----- Validação de parâmetros -----
    if (cmd == "jardim") {
        if (tokens.size() != 3) {
            cout << "comando jardim requer 2 parâmetros\n";
        } else if (!eInteiro(tokens[1]) || !eInteiro(tokens[2])) {
            cout << "parâmetro deve ser inteiro\n";
        } else {
            cout << "[OK] jardim criado " << tokens[1] << "x" << tokens[2] << "\n";
        }
    }
    else if (cmd == "avanca") {
        if (tokens.size() == 1) {
            cout << "[OK] avançou 1 turno\n";
        } else if (tokens.size() == 2 && eInteiro(tokens[1])) {
            cout << "[OK] avançou " << tokens[1] << " turnos\n";
        } else {
            cout << "parâmetro esperado inteiro\n";
        }
    }
    else if (cmd == "fim") {
        cout << "A sair...\n";
        return false;
    }
    else {
        cout << "[OK] comando '" << cmd << "' reconhecido mas ainda sem ação\n";
    }

    return true;
}
