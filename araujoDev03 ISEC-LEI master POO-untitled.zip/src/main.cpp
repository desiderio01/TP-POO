#include <iostream>
#include <string>
#include "../include/command_parser.h"
using namespace std;

int main() {
    string linha;

    cout << ">> ";
    while (getline(cin, linha)) {
        bool continuar = processarComando(linha);
        if (!continuar) break;
        cout << ">> ";
    }
    return 0;
}
